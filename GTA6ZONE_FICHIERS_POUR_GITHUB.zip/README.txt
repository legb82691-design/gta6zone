GTA6ZONE — SITE COMPLET
1. Remplace VOTRE-DOMAINE.com dans sitemap.xml et robots.txt après avoir choisi ton domaine.
2. Mets tous les fichiers dans le même dossier sur ton hébergeur.
3. index.html doit rester à la racine.
4. Active HTTPS.
5. Ajoute le domaine à Google Search Console et envoie sitemap.xml.
6. Complète les pages À propos, Contact, Mentions légales et Confidentialité.
7. Pour AdSense, demande l'examen du site puis utilise le code officiel fourni par Google.
